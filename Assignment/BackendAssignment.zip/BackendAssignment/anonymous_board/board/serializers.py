from rest_framework import serializers
from .models import Post, Comment

class PostSerializer(serializers.ModelSerializer):
    pid = serializers.IntegerField(source='id', read_only=True)

    class Meta:
        model = Post
        fields = ['pid', 'title', 'content', 'create_date']

class CommentSerializer(serializers.ModelSerializer):
    cid = serializers.IntegerField(source='id', read_only=True)

    class Meta:
        model = Comment
        fields = ['cid', 'content', 'create_date', 'post']
        extra_kwargs = {
            'post': {'write_only': True, 'required': False},
        }