from django.shortcuts import render, redirect
from rest_framework import generics
from .models import Post, Comment
from .serializers import PostSerializer, CommentSerializer
from rest_framework.response import Response
from rest_framework import status
from rest_framework.parsers import MultiPartParser, FormParser
from django.views.decorators.csrf import csrf_exempt
from django.utils.decorators import method_decorator
from rest_framework.parsers import JSONParser
from rest_framework.renderers import JSONRenderer

def post_list(request):
    posts = Post.objects.prefetch_related('comments').all()
    post_data = [
        {
            "id": post.id,
            "title": post.title,
            "content": post.content,
            "create_date": post.create_date,
            "comments": [
                {
                    "content": comment.content,
                    "create_date": comment.create_date
                } for comment in post.comments.all()
            ]

        } for post in posts
    ]
    return render(request, 'board/post_list.html', {'posts': post_data})

def post_create(request):
    if request.method == 'POST':
        title = request.POST.get('title')
        content = request.POST.get('content')
        if title and content:
            Post.objects.create(title=title, content=content)
        return redirect('post-list')
    return render(request, 'board/create_post.html')

@method_decorator(csrf_exempt, name='dispatch')
class PostListCreateView(generics.ListCreateAPIView):
    queryset = Post.objects.all()
    serializer_class = PostSerializer
    parser_classes = [JSONParser]
    renderer_classes = [JSONRenderer]

    def list(self, request, *args, **kwargs):
        queryset = self.get_queryset()
        serializer = self.get_serializer(queryset, many=True)
        return Response({"posts": serializer.data})

class PostDetailView(generics.RetrieveAPIView):
    queryset = Post.objects.all()
    serializer_class = PostSerializer

class CommentListCreateView(generics.ListCreateAPIView):
    serializer_class = CommentSerializer
    parser_classes = [JSONParser]

    def get_queryset(self):
        post_id = self.kwargs.get('post_id')
        print(f"DEBUG: Received post_id = {post_id}")
        return Comment.objects.filter(post_id=post_id)

    def list(self, request, *args, **kwargs):
        queryset = self.get_queryset()
        serializer = self.get_serializer(queryset, many=True)
        data = {
            "comments": serializer.data
        }
        return Response(data)

    def perform_create(self, serializer):
        try:
            post_id = self.kwargs.get('post_id')
            print(f"DEBUG: Received post_id = {post_id}")
            post = Post.objects.get(id=post_id)
            print(f"DEBUG: Found Post with id = {post.id}")
            serializer.save(post=post)
        except Post.DoesNotExist:
            print(f"ERROR: Post with id {self.kwargs['post_id']} does not exist.")
            raise

    def create(self, request, *args, **kwargs):
        print(f"DEBUG: Received request.data = {request.data}")
        print(f"DEBUG: kwargs['post-id'] = {kwargs.get('post_id')}")
        content = request.data.get('content')
        if not content:
            return Response({"error": "댓글 내용을 입력하세요."}, status=status.HTTP_400_BAD_REQUEST)

        serializer = self.get_serializer(data=request.data)
        if not serializer.is_valid():
            print(f"DEBUG: Serializer errors: {serializer.errors}")
            return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)
        self.perform_create(serializer)
        headers = self.get_success_headers(serializer.data)
        data = {
            "cid": serializer.data["cid"],
            "content": serializer.data["content"],
            "create_date": serializer.data["create_date"],
            "post": self.kwargs['post_id']
        }
        return Response(data, status=status.HTTP_201_CREATED, headers=headers)