from django.urls import path
from .views import PostListCreateView, PostDetailView, CommentListCreateView
from .views import post_list, post_create

urlpatterns = [
    path('', post_list, name='post-list'),
    path('create', post_create, name='post-create'),
    path('posts/', PostListCreateView.as_view(), name='post-list-create'),
    path('posts/<int:pk>/', PostDetailView.as_view(), name='post-detail'),
    path('posts/<int:post_id>/comment/', CommentListCreateView.as_view(), name='comment-list-create'),
]
